import { Turf } from './turf';

describe('Turf', () => {
  it('should create an instance', () => {
    expect(new Turf()).toBeTruthy();
  });
});
