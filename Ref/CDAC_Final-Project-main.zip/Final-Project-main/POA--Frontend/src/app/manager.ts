export class Manager {
    managerId:number;
    userName:string;
    firstName:string;
    lastName:string;
    mobNo:string;
    emailId:string;
    password:string;


    

    constructor(){
        this.managerId=0;
        this.userName= "";
        this.firstName= "";
        this.lastName= "";
        this.mobNo= "";
        this.emailId= "";
        this.password= "";
    }
}
