export class User {

    userId:number;
    userName:string;
    firstName:string;
    lastName:string;
    mobNo:string;
    emailId:string;
    password:string;
    token: string;
    

    constructor(){
        this.userId=0;
        this.userName= "";
        this.firstName= "";
        this.lastName= "";
        this.mobNo= "";
        this.emailId= "";
        this.password= "";
        this.token="";
    }

}
