export class Turf {

    turfId: number;
    turfName: string;
    turfAdd: string;
    turfFullAdd:string;
    turfType: string;
    managerName: string;
    


    constructor(){
        this.turfId=0;
        this.turfName=" ";
        this.turfAdd=" ";
        this.turfType=" ";
       this.turfFullAdd=" ";
       this.managerName=" ";

    }
}
